//
// Info popovers
//

;(function ($) {
    'use strict';

    $('[data-toggle="popover"]').popover();
})(jQuery);